document.addEventListener('DOMContentLoaded', () => {
  
  // document.addEventListener('scroll', (e) => {
  //   document.querySelector('.navbar-div').classList.add('bg-transparent')
  // })
})